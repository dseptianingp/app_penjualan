'Imports MySql.Data.MySqlClient
Imports System.Data.Odbc


Module Module1
    Public conn As OdbcConnection
    Public cmd As OdbcCommand
    Public dr As OdbcDataReader
    Public da As OdbcDataAdapter
    Public ds As DataSet
    Public str As String

    Sub koneksi()
        str = "Driver={MySQL ODBC 5.1 Driver};database=skripsi_dewi;server=localhost;uid=root"
        conn = New OdbcConnection(str)
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
    End Sub
    
    'CONN = New OdbcConnection("dsn=contohvb")
    'Dim str As String = "Server=localhost;user id=root;password='';database=contohvbnet"

    'CONN = New OdbcConnection(str)


End Module
