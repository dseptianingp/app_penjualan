﻿'Imports MySql.Data.MySqlClient
Imports System.Data.Odbc
Public Class FCustomer
    Sub Kosongkan()
        TKode.Text = ""
        TNama.Text = ""
        TBeli.Text = ""
        TJual.Text = ""
        TJumlah.Text = ""

        TKode.Focus()
        CmdSimpan.Text = "Simpan"
    End Sub

    Sub DataBaru()
        TNama.Text = ""
        TBeli.Text = ""
        TJual.Text = ""
        TJumlah.Text = ""
      
    End Sub

    Sub Tampilkan()
        da = New OdbcDataAdapter("Select * from customer", conn)
        ds = New DataSet
        ds.Clear()
        da.Fill(ds, "customer")
        DGV.DataSource = (ds.Tables("customer"))
        DGV.ReadOnly = True
    End Sub
    Private Sub FCustomer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi()
        Call Tampilkan()
        Kosongkan()
    End Sub

    Private Sub TKode_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TKode.KeyPress
        If e.KeyChar = Chr(13) Then
            Call koneksi()
            cmd = New OdbcCommand("select * from customer where kode_cus='" & TKode.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows = True Then
                TNama.Text = dr.GetString(1)
                TBeli.Text = dr.GetValue(2)
                TJumlah.Text = dr.GetValue(3)
                TJual.Text = dr.GetValue(4)
                TNama.Focus()
                CmdSimpan.Text = "Edit"
            Else
                Call DataBaru()
                TNama.Focus()
            End If
        End If
        '  If Not ((e.KeyChar >= "0" And e.KeyChar <= "9") Or e.KeyChar = vbBack) Then e.Handled() = True

    End Sub

    Private Sub TNama_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TNama.KeyPress
        If e.KeyChar = Chr(13) Then TBeli.Focus()
    End Sub

    Private Sub TBeli_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TBeli.KeyPress
        If e.KeyChar = Chr(13) Then TJumlah.Focus()
    End Sub


    Private Sub TJumlah_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TJumlah.KeyPress
        If e.KeyChar = Chr(13) Then TJual.Focus()
    End Sub

   

    Private Sub TJual_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TJual.KeyPress
        If e.KeyChar = Chr(13) Then CmdSimpan.Focus()
    End Sub

   
   
    Private Sub CmdSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSimpan.Click
        If TKode.Text = "" Or TNama.Text = "" Or TBeli.Text = "" Or TJual.Text = "" Or TJumlah.Text = "" Then
            MsgBox("Data Belum Lengkap")
            Exit Sub
        Else
            Call koneksi()
            cmd = New OdbcCommand("Select * from customer where kode_cus='" & TKode.Text & "'", conn)
            dr = cmd.ExecuteReader()
            dr.Read()
            If Not dr.HasRows Then
                Call koneksi()
                Dim sqltambah As String = "Insert into customer(kode_cus,nama_cus,pic,phone,alamat) values " & _
                "('" & TKode.Text & "','" & TNama.Text & "','" & TBeli.Text & "','" & TJumlah.Text & "','" & TJual.Text & "')"
                cmd = New OdbcCommand(sqltambah, conn)
                cmd.ExecuteNonQuery()
                Call Kosongkan()
                Call Tampilkan()
            Else
                Call koneksi()
                Dim sqledit As String = "Update customer set " & _
                "nama_cus='" & TNama.Text & "', " & _
                "pic='" & TBeli.Text & "', " & _
                "phone='" & TJumlah.Text & "', " & _
                "alamat='" & TJual.Text & "' " & _
                "where kode_cus='" & TKode.Text & "'"
                cmd = New OdbcCommand(sqledit, conn)
                cmd.ExecuteNonQuery()
                Call Kosongkan()
                Call Tampilkan()
            End If
        End If

    End Sub

    Private Sub CmdBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdBatal.Click
        Call Kosongkan()
    End Sub

    Private Sub CmdHapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdHapus.Click
        Call koneksi()
        If TKode.Text = "" Then
            MsgBox("Isi kode barang terlebih dahulu")
            TKode.Focus()
            Exit Sub
        Else

            If MessageBox.Show("Yakin akan dihapus..?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                cmd = New OdbcCommand("Delete  from customer where kode_cus='" & TKode.Text & "'", conn)
                cmd.ExecuteNonQuery()
                Call Kosongkan()
                Call Tampilkan()
            Else
                Call Kosongkan()
            End If
        End If
    End Sub

    Private Sub CmdTutup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdTutup.Click
        Me.Close()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        da = New OdbcDataAdapter("select * from customer where nama_cus like '%" & TextBox1.Text & "%'", conn)
        ds = New DataSet
        da.Fill(ds, "ketemu")
        DGV.DataSource = ds.Tables("ketemu")
        DGV.ReadOnly = True
    End Sub

    Private Sub TKode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TKode.TextChanged

    End Sub
End Class