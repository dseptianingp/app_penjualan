﻿'Imports MySql.Data.MySqlClient
Imports System.Data.Odbc
Public Class Invoice

    Private Sub Invoice_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi()
        Kodeotomatis()
        tampilkan()
        TotalHarga()
        ppn()
    End Sub
    Sub TotalHarga()
        Dim HitungHarga As Integer = 0
        For I As Integer = 0 To DGV.Rows.Count - 1
            HitungHarga = HitungHarga + Val(DGV.Rows(I).Cells(5).Value)
            TextBox4.Text = HitungHarga
            TextBox6.Text = HitungHarga
        Next
    End Sub
    Sub ppn()
        Dim Hasil As Integer = 0
        Dim Hasil2 As Integer = 0
        Hasil = TextBox4.Text * 0.1
        TextBox5.Text = Hasil
        Hasil2 = TextBox4.Text + Hasil
        TextBox6.Text = Hasil2
    End Sub
    Sub tampilkan()
        Try
            Call koneksi()
            da = New OdbcDataAdapter("Select * from detail_inv where no_inv='" & TextBox1.Text & "'", conn)
            ds = New DataSet
            'ds.Clear()
            da.Fill(ds, "detail_inv")
            DGV.DataSource = (ds.Tables("detail_inv"))
            DGV.ReadOnly = True
        Catch ex As Exception
            MsgBox(ex.ToString, "tidak tampil")
        End Try
    End Sub
   
    Sub Kodeotomatis()
        Call koneksi()
        cmd = New OdbcCommand("Select no_inv From invoice where no_inv in(select max(no_inv) from invoice) ", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows = 0 Then
            TextBox1.Text = "INV" + Date.Now.ToString("yyMM") + "00001"
            dr.Close()
        End If
        If Not dr.HasRows Then
            TextBox1.Text = "INV" + Date.Now.ToString("yyMM") + "00001"
            dr.Close()

        Else
            TextBox1.Text = Val(Microsoft.VisualBasic.Right(dr.Item("no_inv").ToString, 4)) + 1
            If Len(TextBox1.Text) = 1 Then
                TextBox1.Text = "INV" + Date.Now.ToString("yyMM") + "0000" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 2 Then
                TextBox1.Text = "INV" + Date.Now.ToString("yyMM") + "000" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 3 Then
                TextBox1.Text = "INV" + Date.Now.ToString("yyMM") + "00" & TextBox1.Text & ""
            ElseIf Len(TextBox1.Text) = 4 Then
                TextBox1.Text = "INV" + Date.Now.ToString("yyMM") + "0" & TextBox1.Text & ""
            End If
            dr.Close()
        End If
    End Sub
    Sub AutoFaktur()
        Call koneksi()
        cmd = New OdbcCommand("Select * from invoice where no_inv in (select max(no_inv) from invoice) order by no_inv desc", conn)
         Dim urutan As String
        Dim hitung As Long
        dr = cmd.ExecuteReader
        dr.Read()
        If Not dr.HasRows Then
            urutan = Format(Now, "yyMM") + "/INV/" + "0001"
        Else
            If Microsoft.VisualBasic.Left(dr.GetString(0), 4) <> Format(Now, "yyMM") Then
                urutan = Format(Now, "yyMM") + "/INV/" + "0001"
            Else
                hitung = dr.GetString(0) + 1
                urutan = Format(Now, "yyMM") + "/INV/" + Microsoft.VisualBasic.Right("0000" & hitung, 4)
            End If
        End If
        TextBox1.Text = urutan

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TampilCusKeInvoice.ShowDialog()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Call koneksi()
        Dim sqltambah As String = "Insert into tmp(kode) values " & _
                "('" & TextBox1.Text & "')"
        cmd = New OdbcCommand(sqltambah, conn)
        cmd.ExecuteNonQuery()
        TampilPenjualanKeINV.ShowDialog()

        'MsgBox("Data Berhasil Tersimpan")
    End Sub

    Private Sub DGV_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellClick
        Call koneksi()
        If DGV.RowCount > 0 Then
            Dim baris As Integer
            With DGV
                baris = .CurrentRow.Index
                If MessageBox.Show("Yakin akan dihapus..?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                    cmd = New OdbcCommand("Delete  from detail_inv where faktur='" & DGV.Item(1, baris).Value & "'", conn)
                    cmd.ExecuteNonQuery()
                    editdatastatus()
                    tampilkan()
                    TotalHarga()
                    ppn()
                Else
                    Call tampilkan()
                    TotalHarga()
                    ppn()
                End If
            End With
        End If
    End Sub
    Sub kosongkan()
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""

    End Sub

    Sub editdatastatus()
        If DGV.RowCount > 0 Then
            Dim baris As Integer
            With DGV
                baris = .CurrentRow.Index
                Call koneksi()
                Dim kurangistok As String = "update penjualan set status_bayar= '" & "Belum Invoice" & "' where faktur='" & DGV.Item(1, baris).Value & "'"
                cmd = New OdbcCommand(kurangistok, conn)
                cmd.ExecuteNonQuery()
            End With
        End If

    End Sub

    Private Sub DGV_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellContentClick

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Then
            MsgBox("Data belum lengkap, tidak ada transaksi atau Pilih Kode dan Nama Customer")
            Exit Sub
        End If
        'simpan ke tabel penjualan
        Call koneksi()
        If DGV.RowCount > 0 Then
            Dim baris As Integer
            With DGV
                baris = .CurrentRow.Index
                Dim simpanmaster As String = "Insert into invoice(no_inv,tgl_inv,periode,note,kode_cus,nama_cus,subtotal,ppn,total) values " & _
                "('" & TextBox1.Text & "','" & Format(DateTimePicker1.Value, "yyyy-MM-dd") & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "')"
                cmd = New OdbcCommand(simpanmaster, conn)
                cmd.ExecuteNonQuery()
                Me.Close()
               
            End With
        End If
        DGV.Columns.Clear()
        Call koneksi()
        kosongkan()
        Kodeotomatis()
        tampilkan()
        TotalHarga()
        ppn()
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged

    End Sub
End Class