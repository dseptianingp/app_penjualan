﻿'Imports MySql.Data.MySqlClient
Imports System.Data.Odbc
Public Class TampilPenjualanKeINV
    Sub tampilkan()
        da = New OdbcDataAdapter("Select * from penjualan where status_bayar='" & "Belum invoice" & "' AND nama_cus='" & ComboBox1.Text & "'", conn)
        ds = New DataSet
        ds.Clear()
        da.Fill(ds, "penjualan")
        DGV.DataSource = (ds.Tables("penjualan"))
    End Sub
    Sub tampilKode()
        cmd = New OdbcCommand("select kode from tmp ", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            TextBox1.Text = dr.Item(0)
          hapustmp()
           
        End If


    End Sub
    Sub hapustmp()

        Try

            Call koneksi()

            Dim str As String

            str = "delete from tmp "

            cmd = New OdbcCommand(str, conn)

            cmd.ExecuteNonQuery()



        Catch ex As Exception



        End Try

    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellClick
        'simpan ke tabel penjualan
        Call koneksi()
        If DGV.RowCount > 0 Then
            Dim baris As Integer
            With DGV
                baris = .CurrentRow.Index
                Dim simpanmaster As String = "Insert into detail_inv(no_inv,faktur,tgl,kode_cus,nama_cus,total,keterangan) values " & _
                "('" & TextBox1.Text & "','" & DGV.Item(0, baris).Value & "','" & Format(DGV.Item(1, baris).Value, "yyyy-MM-dd") & "','" & DGV.Item(2, baris).Value & "','" & DGV.Item(3, baris).Value & "','" & DGV.Item(5, baris).Value & "','" & DGV.Item(6, baris).Value & "')"
                cmd = New OdbcCommand(simpanmaster, conn)
                cmd.ExecuteNonQuery()
                Me.Close()
                Invoice.tampilkan()
                Invoice.TotalHarga()
                Invoice.ppn()
                editdatastatus()
            End With
        End If
       
    End Sub

    Sub editdatastatus()
        If DGV.RowCount > 0 Then
            Dim baris As Integer
            With DGV
                baris = .CurrentRow.Index
                Call koneksi()
                Dim kurangistok As String = "update penjualan set status_bayar= '" & "Sudah Invoice" & "' where faktur='" & DGV.Item(0, baris).Value & "'"
                cmd = New OdbcCommand(kurangistok, conn)
                cmd.ExecuteNonQuery()
            End With
        End If

    End Sub


    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellContentClick

    End Sub

    Private Sub TampilPenjualanKeINV_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi()
        tampilKode()
        tampilkan()
        tampilDataComboBox()

    End Sub

    Sub tampilDataComboBox()
        Try
            Call koneksi()
            ComboBox1.Refresh()
            Dim str As String
            str = "select DISTINCT nama_cus from customer"
            cmd = New OdbcCommand(str, conn)
            dr = cmd.ExecuteReader
            If dr.HasRows Then
                Do While dr.Read

                    ComboBox1.Items.Add(dr("nama_cus"))
                Loop

            Else

            End If
        Catch ex As Exception
            MessageBox.Show("Koneksi Gagal !!!, karena " & ex.Message)
        End Try
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Try

            Call koneksi()
            da = New OdbcDataAdapter("Select * from penjualan where status_bayar='" & "Belum invoice" & "' AND nama_cus='" & ComboBox1.Text & "'", conn)
            ds = New DataSet
            ds.Clear()
            da.Fill(ds, "penjualan")
            DGV.DataSource = (ds.Tables("penjualan"))

        Catch ex As Exception
            MessageBox.Show(ex.ToString, "Data Penjualan kosong.")



        End Try

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub

   
End Class