﻿'Imports MySql.Data.MySqlClient
Imports System.Data.Odbc
Public Class TampilCuskePenjualan
    Sub Tampilkan()
        da = New OdbcDataAdapter("Select * from customer", conn)
        ds = New DataSet
        ds.Clear()
        da.Fill(ds, "customer")
        DGV.DataSource = (ds.Tables("customer"))
        DGV.ReadOnly = True
    End Sub
    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        da = New OdbcDataAdapter("select * from customer where nama_cus like '%" & TextBox1.Text & "%'", conn)
        ds = New DataSet
        da.Fill(ds, "ketemu")
        DGV.DataSource = ds.Tables("ketemu")
        DGV.ReadOnly = True
    End Sub

    Private Sub TampilCuskePenjualan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi()
        Tampilkan()
    End Sub

    Private Sub DGV_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellClick
        If DGV.RowCount > 0 Then
            Dim baris As Integer
            With DGV
                baris = .CurrentRow.Index
                Penjualan.TextBox1.Text = .Item(0, baris).Value
                Penjualan.TextBox2.Text = .Item(1, baris).Value
                Me.Close()
            End With
        End If
    End Sub

    Private Sub DGV_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellContentClick

    End Sub
End Class