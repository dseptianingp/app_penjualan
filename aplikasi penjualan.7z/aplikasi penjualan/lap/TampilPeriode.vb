﻿Imports CrystalDecisions.CrystalReports.Engine
Public Class TampilPeriode

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Dim Reportku As New ReportDocument
        'Reportku.Load("..\..\lap\lap_periode.rpt")
        'Reportku.SetParameterValue("tgl_awal", DateTimePicker1.Text)
        'Reportku.SetParameterValue("tgl_akhir", DateTimePicker2.Text)
        'CrystalReportViewer1.ReportSource = Reportku
        ' CrystalReportViewer1.Refresh()

    End Sub
End Class