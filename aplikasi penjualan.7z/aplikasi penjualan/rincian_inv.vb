﻿'Imports MySql.Data.MySqlClient
Imports System.Data.Odbc
Public Class rincian_inv

    Private Sub rincian_inv_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi()
        TampilFaktur()
    End Sub
    Sub TampilFaktur()
        cmd = New OdbcCommand("select * from invoice", conn)
        dr = cmd.ExecuteReader
        Do While dr.Read
            ComboBox1.Items.Add(dr.GetString(0))
        Loop
    End Sub

    Sub TampilData()
        Call koneksi()
        da = New OdbcDataAdapter("select * from detail_inv where no_inv='" & ComboBox1.Text & "' ", conn)
        ds = New DataSet
        da.Fill(ds, "detail_inv")
        DGV.DataSource = ds.Tables("detail_inv")
        DGV.ReadOnly = True
        Call koneksi()
        cmd = New OdbcCommand("select * from invoice where no_inv='" & ComboBox1.Text & "' ", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            TextBox1.Text = dr.GetValue(0)
            TextBox2.Text = dr.GetValue(1)
            TextBox3.Text = dr.GetValue(2)
            TextBox4.Text = dr.GetValue(3)
            TextBox5.Text = dr.GetValue(4)
            TextBox6.Text = dr.GetValue(5)
            TextBox7.Text = dr.GetValue(6)
            TextBox8.Text = dr.GetValue(7)
            TextBox9.Text = dr.GetValue(8)
          End If

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        TampilData()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        tampil_invoice.Show()
        tampil_invoice.CrystalReportViewer1.SelectionFormula = "totext({invoice1.no_inv}) = '" & ComboBox1.Text & "'"

        tampil_invoice.CrystalReportViewer1.RefreshReport()


        '  tampil_invoice.WindowState = FormWindowState.Maximized

    End Sub
    Sub hapusdetail()
        Call koneksi()
        cmd = New OdbcCommand("Delete  from detail_inv where no_inv='" & ComboBox1.Text & "'", conn)
        cmd.ExecuteNonQuery()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Call koneksi()
        If MessageBox.Show("Yakin akan dihapus..?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then

            hapusdetail()
            cmd = New OdbcCommand("Delete  from invoice where no_inv='" & ComboBox1.Text & "'", conn)
            cmd.ExecuteNonQuery()
            TampilFaktur()
            TampilData()
        End If
    End Sub
End Class