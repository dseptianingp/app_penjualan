﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

  
    Private Sub KELUARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KELUARToolStripMenuItem.Click
        If MessageBox.Show("Tutup Aplikasi...?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            Me.Close()
            End
        End If
    End Sub

    Private Sub DATABARANGToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DATABARANGToolStripMenuItem.Click
        Tampil_lap_barang.Show()
        Tampil_lap_barang.CrystalReportViewer1.RefreshReport()
    End Sub

    Private Sub DATACUSTOMERToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DATACUSTOMERToolStripMenuItem.Click
        Tampil_cus.Show()
        Tampil_cus.CrystalReportViewer1.RefreshReport()
    End Sub

    Private Sub PENJUALANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENJUALANToolStripMenuItem.Click
        Penjualan.ShowDialog()
    End Sub

    Private Sub RINCIANPENJUALANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RINCIANPENJUALANToolStripMenuItem.Click
        RincianTransaksi.Show()
    End Sub

    Private Sub INVOICEToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles INVOICEToolStripMenuItem.Click
        Invoice.ShowDialog()
    End Sub

    Private Sub BARANGToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BARANGToolStripMenuItem.Click
        Barang.ShowDialog()
    End Sub

    Private Sub CUSTOMERToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CUSTOMERToolStripMenuItem.Click
        FCustomer.Show()
    End Sub

    Private Sub PETUGASToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PETUGASToolStripMenuItem.Click
        Petugas.ShowDialog()
    End Sub

    Private Sub RINCIANINVToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RINCIANINVToolStripMenuItem.Click
        rincian_inv.ShowDialog()
    End Sub

    Private Sub LAPPENJUALANPERIODEToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LAPPENJUALANPERIODEToolStripMenuItem.Click
        TampilPeriode.Show()
        TampilPeriode.CrystalReportViewer1.RefreshReport()
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class