'Imports MySql.Data.MySqlClient
Imports System.Data.Odbc
Public Class Petugas

    Sub Kosongkan()
        TKode.Text = ""
        TNama.Text = ""
        TPassword.Text = ""
        CBOStatus.Text = ""
        TKode.Focus()
    End Sub

    Sub DataBaru()
        TNama.Text = ""
        TPassword.Text = ""
        CBOStatus.Text = ""
        TNama.Focus()
    End Sub

    Sub Tampilkan()
        da = New OdbcDataAdapter("Select * from petugas ORDER BY 1", conn)
        ds = New DataSet
        ds.Clear()
        da.Fill(ds, "petugas")
        DGV.DataSource = (ds.Tables("petugas"))
        DGV.ReadOnly = True
    End Sub

    Sub TampilstatusPTG()
        CBOStatus.Items.Clear()
        cmd = New OdbcCommand("select distinct statusptg from petugas", conn)
        dr = cmd.ExecuteReader
        While dr.Read
            CBOStatus.Items.Add(dr.GetString(0))
        End While
    End Sub

    Private Sub Petugas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Call Koneksi()
        Call Tampilkan()
        CBOStatus.Items.Add("ADMIN")
        'CBOStatus.Items.Add("OPERATOR")
        CBOStatus.Items.Add("USER")
    End Sub

    Private Sub TKode_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TKode.KeyPress
        If e.KeyChar = Chr(13) Then
            Call koneksi()
            cmd = New OdbcCommand("select * from petugas where kodeptg='" & TKode.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows = True Then
                TNama.Text = dr.GetString(1)
                TPassword.Text = dr.GetString(2)
                CBOStatus.Text = dr.GetString(3)
                TNama.Focus()
            Else
                Call DataBaru()
                TNama.Focus()
            End If

        End If
    End Sub

    Private Sub TNama_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TNama.KeyPress
        If e.KeyChar = Chr(13) Then TPassword.Focus()
    End Sub

    Private Sub TPassword_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TPassword.KeyPress
        If e.KeyChar = Chr(13) Then CBOStatus.Focus()
    End Sub


    Private Sub CmbStatus_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles CBOStatus.KeyPress
        If e.KeyChar = Chr(13) Then CmdSimpan.Focus()
    End Sub


    Private Sub CmdSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSimpan.Click

        If TKode.Text = "" Or TNama.Text = "" Or TPassword.Text = "" Or CBOStatus.Text = "" Then
            MsgBox("Data Belum Lengkap")
            Exit Sub
        Else
            Call koneksi()
            cmd = New OdbcCommand("Select * from petugas where kodeptg='" & TKode.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If Not dr.HasRows Then
                Call koneksi()
                Dim sqltambah As String = "Insert into petugas(kodeptg,namaptg,passwordptg,statusptg) values " & _
                "('" & TKode.Text & "','" & TNama.Text & "','" & TPassword.Text & "','" & CBOStatus.Text & "')"
                cmd = New OdbcCommand(sqltambah, conn)
                cmd.ExecuteNonQuery()
                Call Kosongkan()
                Call Tampilkan()
            Else
                Call koneksi()
                Dim sqledit As String = "Update petugas set " & _
                "namaptg='" & TNama.Text & "', " & _
                "passwordptg='" & TPassword.Text & "', " & _
                "statusptg='" & CBOStatus.Text & "' where kodeptg='" & TKode.Text & "'"
                cmd = New OdbcCommand(sqledit, conn)
                cmd.ExecuteNonQuery()
                Call Kosongkan()
                Call Tampilkan()
            End If
        End If

    End Sub

    Private Sub CmdBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdBatal.Click
        Call Kosongkan()
    End Sub

    Private Sub CmdTutup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdTutup.Click
        Me.Close()
    End Sub

    Private Sub CmdHapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdHapus.Click
        If TKode.Text = "" Then
            MsgBox("Isi kode Petugas terlebih dahulu")
            TKode.Focus()
            Exit Sub
        Else
            Call koneksi()
            If MessageBox.Show("Yakin akan dihapus..?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                cmd = New OdbcCommand("Delete  from petugas where kodeptg='" & TKode.Text & "'", conn)
                cmd.ExecuteNonQuery()
                Call Kosongkan()
                Call Tampilkan()
            Else
                Call Kosongkan()
            End If
        End If
    End Sub

    Private Sub TKode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TKode.TextChanged

    End Sub
End Class