'Imports MySql.Data.MySqlClient
Imports System.Data.Odbc

Public Class Login


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            If TextBox1.Text = "" Then
                MsgBox("username tidak boleh kosong")
                TextBox1.Focus()
            ElseIf TextBox2.Text = "" Then
                MsgBox("password tidak boleh kosong")
                TextBox2.Focus()
            Else

                Call koneksi()
                cmd = New OdbcCommand("select * from petugas where namaptg='" & TextBox1.Text & "' and passwordptg='" & TextBox2.Text & "'", conn)
                dr = cmd.ExecuteReader
                dr.Read()
                If dr.HasRows Then
                    Me.Hide()
                    koneksi()
                    If dr("statusptg").ToString = "ADMIN" Then

                        Form1.Show()
                        Form1.PETUGASToolStripMenuItem.Enabled = True
                       
                    Else
                        Form1.Show()
                        Form1.PETUGASToolStripMenuItem.Enabled = False
                    End If
                Else
                    MsgBox("login salah, periksa kembali user name dan password")
                    TextBox1.Focus()
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then TextBox2.Focus()
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = Chr(13) Then Button1.Focus()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        End
    End Sub

    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class