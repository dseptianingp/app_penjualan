'Imports MySql.Data.MySqlClient
Imports System.Data.Odbc

Public Class RincianTransaksi

    Sub TampilFaktur()
        cmd = New OdbcCommand("select * from penjualan", conn)
        dr = cmd.ExecuteReader
        Do While dr.Read
            ComboBox1.Items.Add(dr.GetString(0))
        Loop
    End Sub

    Sub TampilData()
        Call koneksi()
        da = New OdbcDataAdapter("select nama_barang,harga_jual,jumlah,subtotal from detailjual where faktur='" & ComboBox1.Text & "' ", conn)
        ds = New DataSet
        da.Fill(ds, "Detail")
        DGV.DataSource = ds.Tables("Detail")
        DGV.ReadOnly = True
        Call koneksi()
        cmd = New OdbcCommand("select tanggal,kode_cus,nama_cus,item,total,keterangan_lain from penjualan where faktur='" & ComboBox1.Text & "' ", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            TTanggal.Text = dr.GetValue(0)
            TDibayar.Text = dr.GetValue(1)
            TKembali.Text = dr.GetValue(2)
            TItem.Text = dr.GetValue(3)
            TTotal.Text = dr.GetValue(4)
            TKasir.Text = dr.GetValue(5)
        End If

    End Sub

    Private Sub RincianTransaksi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call TampilFaktur()
    End Sub

    
    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Call TampilData()
    End Sub

 
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TampilSJ.Show()
        TampilSJ.CrystalReportViewer1.SelectionFormula = "totext({penjualan1.faktur}) = '" & ComboBox1.Text & "'"

        TampilSJ.CrystalReportViewer1.RefreshReport()


        ' TampilSJ.WindowState = FormWindowState.Maximized





    End Sub
    Sub hapusdetail()
        Call koneksi()
        cmd = New OdbcCommand("Delete  from detailjual where faktur='" & ComboBox1.Text & "'", conn)
        cmd.ExecuteNonQuery()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Call koneksi()
        If MessageBox.Show("Yakin akan dihapus..?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then

            hapusdetail()
            cmd = New OdbcCommand("Delete  from penjualan where faktur='" & ComboBox1.Text & "'", conn)
            cmd.ExecuteNonQuery()
            TampilFaktur()
            TampilData()
        End If
    End Sub
End Class