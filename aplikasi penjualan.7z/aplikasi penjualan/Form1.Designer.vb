﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MASTERDATAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PETUGASToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BARANGToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CUSTOMERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TRANSAKSIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PENJUALANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RINCIANPENJUALANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.INVOICEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RINCIANINVToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LAPORANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DATABARANGToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DATACUSTOMERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LAPPENJUALANPERIODEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KELUARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MASTERDATAToolStripMenuItem, Me.TRANSAKSIToolStripMenuItem, Me.LAPORANToolStripMenuItem, Me.KELUARToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1169, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MASTERDATAToolStripMenuItem
        '
        Me.MASTERDATAToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PETUGASToolStripMenuItem, Me.BARANGToolStripMenuItem, Me.CUSTOMERToolStripMenuItem})
        Me.MASTERDATAToolStripMenuItem.Name = "MASTERDATAToolStripMenuItem"
        Me.MASTERDATAToolStripMenuItem.Size = New System.Drawing.Size(96, 20)
        Me.MASTERDATAToolStripMenuItem.Text = "MASTER DATA"
        '
        'PETUGASToolStripMenuItem
        '
        Me.PETUGASToolStripMenuItem.Name = "PETUGASToolStripMenuItem"
        Me.PETUGASToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.PETUGASToolStripMenuItem.Text = "PETUGAS"
        '
        'BARANGToolStripMenuItem
        '
        Me.BARANGToolStripMenuItem.Name = "BARANGToolStripMenuItem"
        Me.BARANGToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.BARANGToolStripMenuItem.Text = "BARANG"
        '
        'CUSTOMERToolStripMenuItem
        '
        Me.CUSTOMERToolStripMenuItem.Name = "CUSTOMERToolStripMenuItem"
        Me.CUSTOMERToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.CUSTOMERToolStripMenuItem.Text = "CUSTOMER"
        '
        'TRANSAKSIToolStripMenuItem
        '
        Me.TRANSAKSIToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PENJUALANToolStripMenuItem, Me.RINCIANPENJUALANToolStripMenuItem, Me.INVOICEToolStripMenuItem, Me.RINCIANINVToolStripMenuItem})
        Me.TRANSAKSIToolStripMenuItem.Name = "TRANSAKSIToolStripMenuItem"
        Me.TRANSAKSIToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.TRANSAKSIToolStripMenuItem.Text = "TRANSAKSI"
        '
        'PENJUALANToolStripMenuItem
        '
        Me.PENJUALANToolStripMenuItem.Name = "PENJUALANToolStripMenuItem"
        Me.PENJUALANToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.PENJUALANToolStripMenuItem.Text = "PENJUALAN"
        '
        'RINCIANPENJUALANToolStripMenuItem
        '
        Me.RINCIANPENJUALANToolStripMenuItem.Name = "RINCIANPENJUALANToolStripMenuItem"
        Me.RINCIANPENJUALANToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.RINCIANPENJUALANToolStripMenuItem.Text = "RINCIAN PENJUALAN"
        '
        'INVOICEToolStripMenuItem
        '
        Me.INVOICEToolStripMenuItem.Name = "INVOICEToolStripMenuItem"
        Me.INVOICEToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.INVOICEToolStripMenuItem.Text = "INVOICE"
        '
        'RINCIANINVToolStripMenuItem
        '
        Me.RINCIANINVToolStripMenuItem.Name = "RINCIANINVToolStripMenuItem"
        Me.RINCIANINVToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.RINCIANINVToolStripMenuItem.Text = "RINCIAN INV"
        '
        'LAPORANToolStripMenuItem
        '
        Me.LAPORANToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DATABARANGToolStripMenuItem, Me.DATACUSTOMERToolStripMenuItem, Me.LAPPENJUALANPERIODEToolStripMenuItem})
        Me.LAPORANToolStripMenuItem.Name = "LAPORANToolStripMenuItem"
        Me.LAPORANToolStripMenuItem.Size = New System.Drawing.Size(73, 20)
        Me.LAPORANToolStripMenuItem.Text = "LAPORAN"
        '
        'DATABARANGToolStripMenuItem
        '
        Me.DATABARANGToolStripMenuItem.Name = "DATABARANGToolStripMenuItem"
        Me.DATABARANGToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.DATABARANGToolStripMenuItem.Text = "DATA BARANG"
        '
        'DATACUSTOMERToolStripMenuItem
        '
        Me.DATACUSTOMERToolStripMenuItem.Name = "DATACUSTOMERToolStripMenuItem"
        Me.DATACUSTOMERToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.DATACUSTOMERToolStripMenuItem.Text = "DATA CUSTOMER"
        '
        'LAPPENJUALANPERIODEToolStripMenuItem
        '
        Me.LAPPENJUALANPERIODEToolStripMenuItem.Name = "LAPPENJUALANPERIODEToolStripMenuItem"
        Me.LAPPENJUALANPERIODEToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.LAPPENJUALANPERIODEToolStripMenuItem.Text = "LAP PENJUALAN PERIODE"
        '
        'KELUARToolStripMenuItem
        '
        Me.KELUARToolStripMenuItem.Name = "KELUARToolStripMenuItem"
        Me.KELUARToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.KELUARToolStripMenuItem.Text = "KELUAR"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1169, 676)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "MenuUtama"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MASTERDATAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PETUGASToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BARANGToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CUSTOMERToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TRANSAKSIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAPORANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KELUARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PENJUALANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RINCIANPENJUALANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents INVOICEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DATABARANGToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DATACUSTOMERToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RINCIANINVToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAPPENJUALANPERIODEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
